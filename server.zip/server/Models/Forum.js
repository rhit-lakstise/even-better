const mongoose = require('mongoose');

const PostSchema = mongoose.Schema(
    {

        "title": {
            type: String,
            required: true,
        },
        "poster": String,
        "content": String,
        "timestamp": Number,
        "tags": [String],
        "comments": [{
            "commenter": String,
            "likes": Number,
            "timestamp": Number,
            "content": String
        }],
        "likes": Number,

        })

module.exports = mongoose.model('PostModel', PostSchema)