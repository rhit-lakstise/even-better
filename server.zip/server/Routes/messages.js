const Conversation = require('../Models/Conversation');
const express = require('express');
const router = express.Router();



router.get('/conversation', async (req, res) => {
    console.log('searched for a conversation')
    try{
        let conversation = await Conversation.find({$or: [{"users": [req.query['sender'], req.query['recipient']]}, {"users": [req.query['recipient'], req.query['sender']]}]});
        console.log(conversation)
        if(conversation.length == 0){
            conversation = new Conversation({
                "users": [req.query['sender'], req.query['recipient']],
            })
            conversation.save();
            res.json(conversation);
        }
        else {
            res.json(conversation[0]);
        }
    } catch(err){
        console.log(err)
        res.json({message: "Error!"})
    }
})




module.exports = router;